name             'Webapp'
maintainer       'Webapp Inc.'
maintainer_email 'loungeict5@gmail.com'
license          'All rights reserved'
description      'Installs/Webapp'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.0.0'
